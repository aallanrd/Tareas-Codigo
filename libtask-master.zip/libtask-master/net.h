/* Copyright (c) 2005 Russ Cox, MIT; see COPYRIGHT */

#ifndef _NET_H_
#define _NET_H_ 1

#include <stdarg.h>
#include <inttypes.h>

/*
 * Network dialing - sets non-blocking automatically
 */
enum
{
	UDP = 0,
	TCP = 1,
};

int		netannounce(int, char*, int);
int		netaccept(int, char*, int*);
int		netdial(int, char*, int);
int		netlookup(char*, uint32_t*);	/* blocks entire program! */
int		netdial(int, char*, int);

#endif

