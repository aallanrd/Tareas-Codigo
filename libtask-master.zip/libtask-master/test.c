#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "task.h"
#include "mem.h"

enum {STACK = 32768};

void printMatrix(void* _matrix,int cols,int rows) {
	int (*matrix)[cols] = _matrix;
	printf("rows: %d, cols: %d\n",rows,cols);
	int i,j;
	for (i=0; i<cols; i++) {
		for (j=0; j<rows; j++) {
			printf("%d",matrix[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

void memInfoTask(void *arg) {
    tasksystem();
    while (1==1) {
        meminfo();
        taskyield();
    }
}

void myTask(void *arg) {
	
	int rowCount = (rand()%19)+1;
	int colCount = (rand()%19)+1;
	int (*matrix)[colCount];
		
	matrix = (int(*)[colCount])malloc(sizeof(*matrix)*rowCount*colCount);
	taskyield();
	
	int i,j;
	for (i=0; i<colCount; i++) {
		for (j=0; j<rowCount; j++) {
			matrix[i][j] = rand()%10;
		}
	}
	
	printMatrix(matrix,colCount,rowCount);
	
	free(matrix);
	
	taskyield();
	taskexit(0);
}

void taskmain(int argc, char **argv) {
  taskcreate(memInfoTask,(void*)NULL,STACK);
  int i;
  for (i=0; i < 10; i++) {
    taskcreate(myTask,(void*)i,STACK);
  }
}
