/* Copyright (c) 2005 Russ Cox, MIT; see COPYRIGHT */

#ifndef _QLOCK_H_
#define _QLOCK_H_ 1

#include <stdarg.h>
#include <inttypes.h>
#include "task.h"
#include "taskimpl.h"	

/*
 * queuing locks
 */
typedef struct QLock QLock;
struct QLock
{
	Task	*owner;
	Tasklist waiting;
};

void	qlock(QLock*);
int	canqlock(QLock*);
void	qunlock(QLock*);

/*
 * reader-writer locks
 */
typedef struct RWLock RWLock;
struct RWLock
{
	int	readers;
	Task	*writer;
	Tasklist rwaiting;
	Tasklist wwaiting;
};

void	rlock(RWLock*);
int	canrlock(RWLock*);
void	runlock(RWLock*);

void	wlock(RWLock*);
int	canwlock(RWLock*);
void	wunlock(RWLock*);

#endif

