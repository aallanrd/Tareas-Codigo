/* Copyright (c) 2005 Russ Cox, MIT; see COPYRIGHT */

#ifndef _TASK_H_
#define _TASK_H_ 1

#ifdef __cplusplus
extern "C" {
#endif

#include <stdarg.h>
#include <inttypes.h>

/*
 * basic procs and threads
 */

typedef struct Task Task;
typedef struct Tasklist Tasklist;

int anyready(void);
int taskcreate(void (*f)(void *arg), void *arg, unsigned int stacksize);
void taskexit(int);
void taskexitall(int);
void taskmain(int argc, char *argv[]);
int taskyield(void);
void **taskdata(void);
void needstack(int);
void taskname(char *, ...);
void taskstate(char *, ...);
char *taskgetname(void);
char *taskgetstate(void);
void tasksystem(void);
unsigned int taskdelay(unsigned int);
unsigned int taskid(void);
void taskinfo(int s);
void *taskstack(void);

    struct Tasklist /* used internally */
    {
  Task *head;
  Task *tail;
};

Tasklist taskrunqueue;

#ifdef __cplusplus
}
#endif
#endif
