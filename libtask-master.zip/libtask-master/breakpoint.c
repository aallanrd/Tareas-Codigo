#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <task.h>
#include <fd.h>

#define SAVE 0
#define LOAD 1

enum { STACK = 32768 };

char buffer[STACK] = "";
int mode=LOAD;

void savebuffer(char *filename, char *buffer, int size) {
  FILE *f1;
  if ((f1 = fopen(filename, "w")) == -1) {
    taskexit(-1);
  }
  fdnoblock(f1);
  if (fdwrite(f1, buffer, size) != size)
    printf("cp: write error on file %s\n", filename);
  fclose(f1);
}

void fibonacci(void *arg) {
  int n, first = 0, second = 1, next, c;
  char *stk;
  
  n = (int)arg;

  for (c = 0; c < n; c++) {

    if (c == 10) {
      stk = taskstack();
	  mode=SAVE;
	  memcpy(buffer,&stk,STACK);
	  if (mode==SAVE)
        savebuffer("break1", buffer, STACK);		
    }
    if (c <= 1)
      next = c;
    else {
      next = first + second;
      first = second;
      second = next;
    }
    printf("%d\n", next);
  }
}

void taskmain(int argc, char **argv) {
  if (argc == 0) {
    printf("Usage: breakpoint n\n");
    taskexit(-1);
  }
  taskcreate(fibonacci, atoi(argv[1]), STACK);
}