/* Copyright (c) 2005 Russ Cox, MIT; see COPYRIGHT */

#ifndef _RENDEZ_H_
#define _RENDEZ_H_ 1

#include <stdarg.h>
#include <inttypes.h>
#include "qlock.h"

/*
 * sleep and wakeup (condition variables)
 */
typedef struct Rendez Rendez;

struct Rendez
{
	QLock	*l;
	Tasklist waiting;
};

void	tasksleep(Rendez*);
int	taskwakeup(Rendez*);
int	taskwakeupall(Rendez*);

#endif

