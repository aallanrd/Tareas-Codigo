#ifndef _DIR_H_
#define _DIR_H_ 1

#define NAME_MAX 14 /* longest filename component; */
                    /* system-dependent */

#ifndef DIRSIZ
#define DIRSIZ 14
#endif

#define DT_DIR 0040000 /* directory */
#define DT_CHR 0020000 /* character special */
#define DT_BLK 0060000 /* block special */
#define DT_REG 0010000 /* regular */

struct direct {        /* directory entry */
  ino_t d_ino;         /* inode number */
  char d_name[DIRSIZ]; /* long name does not have '\0' */
};

typedef struct {           /* portable directory entry */
  long ino;              /* inode number */
  long offset; 			   /* file offset; */
  unsigned char type;     /*  type of file */
  char name[NAME_MAX + 1]; /* name + '\0' terminator */
} Dirent;

typedef struct {/* minimal DIR: no buffering, etc. */
  int fd;       /* file descriptor for the directory */
  Dirent d;     /* the directory entry */
} DIR;

DIR *opendir(char *dirname);
Dirent *readdir(DIR *dfd);
void closedir(DIR *dfd);

#endif